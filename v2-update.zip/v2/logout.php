<?php 

session_start();

if(isset($_SESSION['loginsession'])) {
    unset($_SESSION['loginsession']);
    session_destroy();
}

?>