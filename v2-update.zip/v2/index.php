<?php

session_start();

$db = new PDO("mysql:host=127.0.0.1;dbname=smartparking", "smartparking", "sm4rtp4rk1ng991");
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

?>

<!DOCTYPE html>
<html>

<head>
	<link rel="shortcut icon" href="favicon.ico">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ATM Beras | IASCR | Universitas Hasanuddin</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Charm:wght@400;700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
	<style type="text/css">
		*,
		*::before,
		*::after {
			box-sizing: border-box;
		}

		html,
		body {
			margin: 0;
			padding: 0;
		}

		body {
			font-family: "Roboto";
			font-size: 1rem;
			background-color: #004d40;
			color: #333;
		}

		th::after {
			display: block;
			content: " \296E";
			float: right;
			font-size: 1rem;
		}

		h1 {
			font-family: 'Charm';
			font-size: 2.2rem;
			color: #efefef;
			margin: 40px 15px;
			display: block;
			text-align: center;
		}

		.tabs {
			margin: 0 auto 25px;
			max-width: 80%;
		}

		.content {
			background-color: #ffffff;
			border-radius: 0 3px 3px 3px;
			padding: 15px;
			min-height: 400px;
			box-shadow: 0 10px 10px #111;
		}

		ul {
			list-style: none;
			margin: 0;
			padding: 0;
		}

		li {
			display: inline-block;
		}

		a {
			display: block;
			padding: 10px 15px;
			width: 150px;
			text-decoration: none;
			background-color: #fff;
			border-radius: 3px 3px 0 0;
			background-color: #ccc;
			color: #555;
			font-weight: bold;
			text-align: center;
		}

		a.active {
			border-top: 3px solid #ffcc00;
			position: relative;
			background-color: #ffffff;
			color: #333;
		}

		a.active::before {
			position: absolute;
			content: "";
			height: 80px;
			width: 100%;
			top: 0;
			left: 0;
			border-radius: 3px;
			background-color: #efefef;
			display: block;
			z-index: -1;
		}

		hr {
			border: 0;
			border-bottom: 1px solid #aaa;
		}

		table,
		tr,
		th,
		td {
			border: 1px solid #aaa;
		}

		table {
			border-collapse: collapse;
			width: 100%;
		}

		.loginbox {
			margin: 25px auto 0;
			width: 320px;
		}

		.loginbox input,
		.loginbox button {
			width: 100%;
			padding: 10px 15px;
			margin-bottom: 15px;
		}

		.info {
			padding: 15px;
			border: 1px solid #aaa;
			border-left: 5px solid #fc0;
		}

		input,
		textarea {
			border: 1px solid #ccc;
			border-radius: none;
			font-family: inherit;
			font-size: 1rem;
		}

		input:focus,
		textarea:focus {
			outline: 1px solid #004d40;
		}

		.submit {
			border: 0;
			height: 50px;
			background-color: #fc0;
			font-family: inherit;
			font-size: 1rem;
		}

		th,
		td {
			padding: 7px 15px;
			text-align: left;
		}

		th {
			background-color: #efefef;
		}

		.error,
		.popup-error,
		.popup-success,
		.popup-error2,
		.popup-success2 {
			width: 100%;
			border: 1px solid #aaa;
			padding: 15px;
			border-left: 5px solid #f05;
			padding: 7px 15px;
			display: none;
		}

		.popup-success,
		.popup-success2 {
			border-left-color: #5f0;
		}

		.popup-error,
		.popup-success,
		.popup-error2,
		.popup-success2 {
			margin-bottom: 10px;
		}

		.btn {
			border: 0;
			border-radius: 3px;
			font-family: inherit;
			font-size: 1rem;
			padding: 7px 15px;
		}

		.blue {
			background-color: #50f;
			color: #efefef;
		}

		.green {
			background-color: #00A758;
			color: #efefef;
		}

		.red {
			background-color: #EC3137;
			color: #efefef;

		}

		.yellow {
			background-color: #fc0;
			color: #333;
		}

		.popup,
		.popup2 {
			max-width: 500px;
			width: 100%;
			position: absolute;
			z-index: 10;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			background-color: #fff;
			padding: 25px 50px;
		}

		.popup input,
		.popup textarea,
		.popup button,
		.popup2 input,
		.popup2 textarea,
		.popup2 button {
			width: 100%;
			margin-bottom: 10px;
			font-family: inherit;
			font-size: 1rem;
			padding: 10px 15px;
		}

		.popup-background,
		.popup-background2 {
			background-color: #0005;
			position: fixed;
			top: 0;
			left: 0;
			height: 0;
			width: 0;
			overflow: hidden;
			transition: all .25s linear;
			transition-property: height, width;
		}

		.popup-background.active,
		.popup-background2.active {
			z-index: 9;
			top: 0;
			left: 0;
			bottom: 0;
			right: 0;
			width: 100%;
			height: 100%;
			transition: all .25s linear;
			transition-property: height, width;
		}

		.popup-tambah {
			margin-top: 10px;
			border: 0;
			background-color: #fc0;
			height: 50px;
		}
	</style>
</head>

<body>
	<h1>ATM Beras<br />IASCR - Universitas Hasanuddin</h1>
	<div class="tabs">
		<div class="menu">
			<ul>
				<li><a class="item active" data-target="content1" onclick="updateStr(1)">Pelanggan</a></li>
				<li><a class="item" data-target="content2" onclick="updateStr(2)">Admin</a></li>
			</ul>
		</div>
		<div class="content">
			<div id="content1">
				<div class="titles">
					<h2 style="float: left;">Halaman Pelanggan</h2>
					<img src="logo2.png" style="max-width: 160px;float: right;" />
					<div style="display: table;clear: both;content: ''"></div>
				</div>
				<hr />
				<br />
				<table id="m_list">
					<tr>
						<th data-id="nama" onclick='return sorting(this)'>Nama Lengkap</th>
						<th data-id="alamat" onclick='return sorting(this)'>Alamat</th>
						<th data-id="sisa_saldo" onclick='return sorting(this)'>Sisa Saldo</th>
						<th data-id="akses_terakhir" onclick='return sorting(this)'>Akses Terakhir</th>
					</tr>
					<?php
					$sql = "SELECT nama,alamat,sisa_saldo,akses_terakhir FROM pelanggan";
					$stmt = $db->query($sql);
					while ($data = $stmt->fetch()) {
					?>

						<tr>
							<td><?php echo $data['nama'] ?></td>
							<td><?php echo $data['alamat'] ?></td>
							<td><?php echo $data['sisa_saldo'] ?></td>
							<td><?php echo $data['akses_terakhir'] ?></td>
						</tr>

					<?php } ?>
				</table>
			</div>
			<div id="content2" style="display: none;">
				<div class="titles">
					<?php if (isset($_SESSION['loginsession'])) : ?>
						<h2 class="after-logout" style="float: left;">Halaman Admin</h2>
					<?php else : ?>
						<h2 class="after-login" style="float: left;">Halaman Login</h2>
					<?php endif; ?>

					<img src="logo2.png" style="max-width: 160px;float: right;" />
					<div style="display: table;clear: both;content: ''"></div>
				</div>
				<hr />
				<div id="r-content">
					<?php if (isset($_SESSION['loginsession'])) : ?>
						<br />
						<div style="text-align: right;">
							Selamat Datang, <b><?php echo strtoupper($_SESSION['loginsession']); ?></b>,&nbsp;&nbsp;&nbsp;
							<button class="btn green" onclick="popup()">Tambah Pelanggan</button>&nbsp;
							<button class="btn red" onclick="logout()">Keluar</button>
						</div>
						<br />
						<table id="a_list">
							<tr>
								<th data-id="id" onclick='return sorting(this)'>ID</th>
								<th data-id="nama" onclick='return sorting(this)'>Nama Lengkap</th>
								<th data-id="alamat" onclick='return sorting(this)'>Alamat</th>
								<th data-id="pin" onclick='return sorting(this)'>Pin</th>
								<th data-id="sisa_saldo" onclick='return sorting(this)'>Sisa Saldo</th>
								<th data-id="akses_terakhir" onclick='return sorting(this)'>Akses Terakhir</th>
								<th onclick='return sorting(this)'>Opsi</th>
							</tr>
							<?php
							$sql = "SELECT * FROM pelanggan";
							$stmt = $db->query($sql);
							while ($data = $stmt->fetch()) {
							?>
								<tr>
									<td><?php echo $data['id'] ?></td>
									<td><?php echo $data['nama'] ?></td>
									<td><?php echo $data['alamat'] ?></td>
									<td><?php echo $data['pin'] ?></td>
									<td><?php echo $data['sisa_saldo'] ?></td>
									<td><?php echo $data['akses_terakhir'] ?></td>
									<td style="text-align: center;">
										<button class="btn red" data-id="<?php echo $data['id']; ?>" onclick="return hapus(this)">Hapus</button>
										<button class="btn yellow" data-id="<?php echo $data['id']; ?>" onclick="return edit(this)">Edit</button>
									</td>
								</tr>

							<?php } ?>
						</table>


					<?php else : ?>
						<div class="loginbox">
							<div class="error"></div>
							<p class="info">
								Lakukan 'Login' terlebih dahulu untuk melanjutkan.
							</p>
							<form id="forms">
								<input type="text" name="uname" id="uname" placeholder="Nama Pengguna" />
								<input type="password" name="password" id="password" placeholder="Kata Sandi" />
								<button class="submit" type="submit">Login</button>
							</form>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>

	<div class="popup-background">
		<form class="popup" id="popup-form" onsubmit="return processPopupForm(this)">
			<h2>Tambah Pengguna Baru</h2>
			<hr>
			<br>
			<div class="popup-error"></div>
			<div class="popup-success"></div>
			<input type="text" name="id" placeholder="ID" autocomplete="off" id="x" />
			<input type="text" name="nama" placeholder="Nama Lengkap" autocomplete="off" id="y" />
			<textarea name="alamat" placeholder="Alamat" autocomplete="off" id="z"></textarea>
			<input type="text" name="pin" placeholder="Pin" autocomplete="off" id="a" />
			<input type="text" name="sisa_saldo" placeholder="Sisa Saldo" autocomplete="off" id="b" />
			<button type="submit" class="popup-tambah">Tambah</button>
		</form>
	</div>
	<div class="popup-background2">
		<form class="popup2" id="popup-form2" onsubmit="return processPopupForm2(this)">
			<h2>Edit Data Pengguna</h2>
			<hr>
			<br>
			<div class="popup-error2"></div>
			<div class="popup-success2"></div>
			<input type="text" name="id2" placeholder="ID" autocomplete="off" id="x" disabled />
			<input type="text" name="nama2" placeholder="Nama Lengkap" autocomplete="off" id="y" />
			<textarea name="alamat2" placeholder="Alamat" autocomplete="off" id="z"></textarea>
			<input type="text" name="pin2" placeholder="Pin" autocomplete="off" id="a" />
			<input type="text" name="sisa_saldo2" placeholder="Sisa Saldo" autocomplete="off" id="b" />
			<button type="submit" class="popup-tambah">Edit</button>
		</form>
	</div>

	<script type="text/javascript">
		var state = 1;
		var organize = "";
		var ascpos = 1;

		setInterval(async function() {
			ucontent = "";
			if (state == 1) {
				let res = await fetch(`update-guest.php?by=${organize}&asc=${ascpos}`);
				if (res.ok) {
					let udata = await res.json();
					ucontent += `
						<tr>
							<th data-id="nama" onclick='return sorting(this)'>Nama Lengkap</th>
							<th data-id="alamat" onclick='return sorting(this)'>Alamat</th>
							<th data-id="sisa_saldo" onclick='return sorting(this)'>Sisa Saldo</th>
							<th data-id="akses_terakhir" onclick='return sorting(this)'>Akses Terakhir</th>
						</tr>
					`
					for (var ud of udata) {
						ucontent += `
						<tr>
							<td>${ud.nama}</td>
							<td>${ud.alamat}</td>
							<td>${ud.sisa_saldo}</td>
							<td>${ud.akses_terakhir}</td>
						</tr>
						`
					}
				}
				document.getElementById("m_list").innerHTML = ucontent;
			} else {
				let res = await fetch(`update-admin.php?by=${organize}&asc=${ascpos}`);
				if (res.ok) {
					let udata = await res.json();
					ucontent += `
						<tr>
							<th data-id='id' onclick='return sorting(this)'>ID</th>
							<th data-id='nama' onclick='return sorting(this)'>Nama Lengkap</th>
							<th data-id='alamat' onclick='return sorting(this)'>Alamat</th>
							<th data-id='pin' onclick='return sorting(this)'>Pin</th>
							<th data-id='sisa_saldo' onclick='return sorting(this)'>Sisa Saldo</th>
							<th data-id='akses_terakhir' onclick='return sorting(this)'>Akses Terakhir</th>
							<th onclick='return sorting(this)'>Opsi</th>
						</tr>
					`
					for (var ud of udata) {
						ucontent += `
							<tr>
								<td>${ud.id}</td>
								<td>${ud.nama}</td>
								<td>${ud.alamat}</td>
								<td>${ud.pin}</td>
								<td>${ud.sisa_saldo}</td>
								<td>${ud.akses_terakhir}</td>
								<td style="text-align: center;">
									<button class="btn red" data-id="${ud.id}" onclick="return hapus(this)">Hapus</button>
									<button class="btn yellow" data-id="${ud.id}" onclick="return edit(this)">Edit</button>
								</td>
							</tr>
						`
					}
				}
				document.getElementById("a_list").innerHTML = ucontent;
			}
		}, 2500);

		var ignoreClickOnMeElement = document.getElementsByClassName('popup')[0];
		var ignoreClickOnMeElement2 = document.getElementsByClassName('popup2')[0];

		document.querySelector('.popup-background').addEventListener('click', function(event) {
			var isClickInsideElement = ignoreClickOnMeElement.contains(event.target);
			if (!isClickInsideElement) {
				document.querySelector('.popup-background').classList.remove("active");
			}
		});
		document.querySelector('.popup-background2').addEventListener('click', function(event) {
			var isClickInsideElement = ignoreClickOnMeElement2.contains(event.target);
			if (!isClickInsideElement) {
				document.querySelector('.popup-background2').classList.remove("active");
			}
		});

		function sorting(item) {
			var table, rows, switching, i, x, y, shouldSwitch, elem;
			elem = item.cellIndex;
			var asc = true;
			var s = item.getAttribute("data-sort");
			if (s == null || s == 1)
				item.dataset.sort = 2
			else {
				item.dataset.sort = 1
				asc = false;
			}
			if (item.getAttribute("data-id") != "") {
				organize = item.getAttribute("data-id");
				ascpos = (asc == true) ? 1 : 2;
			}

			table = document.getElementById(item.parentNode.parentNode.parentNode.id);
			switching = true;
			while (switching) {
				switching = false;
				rows = table.rows;
				for (i = 1; i < (rows.length - 1); i++) {
					shouldSwitch = false;
					x = rows[i].getElementsByTagName("TD")[elem];
					y = rows[i + 1].getElementsByTagName("TD")[elem];
					if (asc) {
						var a = x.textContent;
						var b = y.textContent;

						if (isNaN(a)) {
							if (a.toLowerCase() > b.toLowerCase()) {
								shouldSwitch = true;
								break;
							}
						} else {
							if (Number(a) > Number(b)) {
								shouldSwitch = true;
								break;
							}
						}
					} else {
						var a = x.textContent;
						var b = y.textContent;

						if (isNaN(a)) {
							if (a.toLowerCase() < b.toLowerCase()) {
								shouldSwitch = true;
								break;
							}
						} else {
							if (Number(a) < Number(b)) {
								shouldSwitch = true;
								break;
							}
						}
					}
				}
				if (shouldSwitch) {
					rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
					switching = true;
				}
			}
		}

		var items = document.querySelectorAll(".item");
		items.forEach(function(i) {
			i.addEventListener("click", function() {

				items.forEach(function(m) {
					if (m.classList.contains("active")) {
						m.classList.remove("active");
						document.querySelector(`#${m.getAttribute("data-target")}`).style.display = "none";
					}
				});

				if (!i.classList.contains("active")) {
					document.querySelector(`#${i.getAttribute("data-target")}`).style.display = "block";
					i.classList.add("active");
				}
			});
		});

		document.querySelector("#forms").addEventListener("submit", function(e) {
			e.preventDefault();
			sendForm();
		});


		function updateStr(val) {
			state = val;
		}

		function processForm() {
			sendForm();
			return false;
		}


		function sendForm() {
			if (document.querySelector("#uname").value == "" || document.querySelector("#password").value == "") {
				var err = document.querySelector(".error");
				err.style.display = "block";
				err.textContent = "Nama Pengguna/Kata Sandi kosong!";
			} else {
				var xml = new XMLHttpRequest();
				xml.onload = function() {
					if (this.status == 200) {
						var res = this.responseText;
						//console.log(res);
						if (res == 204) {
							var lerr = document.querySelector(".error");
							lerr.style.display = "block";
							lerr.textContent = "Nama Pengguna/Kata Sandi salah!";
						} else {
							processTable(res);
						}
					}
				}
				xml.open("POST", "process.php", true);
				xml.send(`${document.querySelector("#uname").value}, ${document.querySelector("#password").value}`);
			}
		}

		function processTable(data) {
			dd = JSON.parse(data);
			var cc = document.querySelector("#r-content");
			var tmp = `
				<br />
				<div style = "text-align: right;">
					Selamat Datang, <b> ${dd['u']}</b>,&nbsp;&nbsp;&nbsp;
					<button class="btn green" onclick="popup()">Tambah Pelanggan</button>&nbsp;
					<button class="btn red" onclick="logout()">Keluar</button>
				</div><br />
			<table id='a_list'>
			`;
			tmp += `
				<tr>
					<th data-id='id' onclick='return sorting(this)'>ID</th>
					<th data-id='nama' onclick='return sorting(this)'>Nama Lengkap</th>
					<th data-id='alamat' onclick='return sorting(this)'>Alamat</th>
					<th data-id='pin' onclick='return sorting(this)'>Pin</th>
					<th data-id='sisa_saldo' onclick='return sorting(this)'>Sisa Saldo</th>
					<th data-id='akses_terakhir' onclick='return sorting(this)'>Akses Terakhir</th>
					<th onclick='return sorting(this)'>Opsi</th>
				</tr>
			`;
			for (var i = 0; i < dd['d'].length; ++i) {
				tmp += `
					<tr>
						<td>${dd['d'][i].id}</td>
						<td>${dd['d'][i].nama}</td>
						<td>${dd['d'][i].alamat}</td>
						<td>${dd['d'][i].pin}</td>
						<td>${dd['d'][i].sisa_saldo}</td>
						<td>${dd['d'][i].akses_terakhir}</td>
						<td style="text-align: center;">
							<button class="btn red" data-id="${dd['d'][i].id}" onclick="return hapus(this)">Hapus</button>
							<button class="btn yellow" data-id="${dd['d'][i].id}" onclick="return edit(this)">Edit</button>
						</td>
					</tr>
				`;
			}
			tmp += "</table>";
			cc.innerHTML = tmp;
			document.querySelector(".after-login").textContent = "Halaman Admin";
		}

		function logout() {

			var xml = new XMLHttpRequest();

			xml.onload = function() {
				if (this.status == 200) {

					document.querySelector("#r-content").innerHTML = `<div class="loginbox">
					<div class="error"></div>
						<p class="info">
							Lakukan 'Login' terlebih dahulu untuk melanjutkan.
						</p>
						<form action="" method="POST" id="forms" onsubmit="return processForm()">
							<input type="text" name="uname" id="uname" placeholder="Nama Pengguna" />
							<input type="password" name="password" id="password" placeholder="Kata Sandi" />
							<button class="submit" type="submit">Login</button>
						</form>
					</div>`;
					document.querySelector(".after-login").textContent = "Halaman Login";
					document.querySelector(".after-logout").textContent = "Halaman Login";
				}
			}

			xml.open("GET", "logout.php");
			xml.send(null);

		}

		function popup() {
			document.querySelector(".popup-background").classList.add("active");
			document.querySelector(".popup-error").style.display = "none";
			document.querySelector(".popup-success").style.display = "none";
			fr = document.querySelector("#popup-form");
			for (var i = 0; i < fr.elements.length - 1; ++i) {
				fr.elements[i].value = "";
			}

		};


		function processPopupForm(data) {
			for (var i = 0; i < data.elements.length - 1; ++i) {
				if (data.elements[i].value == "") {
					document.querySelector(".popup-error").style.display = "block";
					document.querySelector(".popup-error").textContent = "Field tidak boleh kosong.";
					return false;
				}
			}
			var req = []
			for (var i = 0; i < data.elements.length - 1; ++i)
				req.push(data.elements[i].value);
			req = req.join(",");
			var xml = new XMLHttpRequest();
			xml.onload = function() {
				if (this.status == 200) {
					var res = this.responseText;
					//console.log(res);
					var lerr = document.querySelector(".popup-error");
					var lsuc = document.querySelector(".popup-success");
					if (res == 204) {
						lerr.style.display = "block";
						lsuc.style.display = "none";
						lerr.textContent = "Data gagal ditambahkan ulangi!";
					} else if (res == 205) {
						lerr.style.display = "block";
						lsuc.style.display = "none";
						lerr.textContent = "ID sudah terdaftar, coba dengan ID berbeda.";
					} else {
						lerr.style.display = "none";
						lsuc.style.display = "block";
						lsuc.textContent = "Data berhasil ditambahkan";
						processTable(res);
					}
				}
			}
			xml.open("POST", "add.php", true);
			xml.send(req);
			return false;
		}

		function processPopupForm2(data) {
			for (var i = 0; i < data.elements.length - 1; ++i) {
				if ((data.elements[i].value).trim() == "") {
					document.querySelector(".popup-error2").style.display = "block";
					document.querySelector(".popup-error2").textContent = "Field tidak boleh kosong.";
					return false;
				}
			}

			var req = []
			for (var i = 0; i < data.elements.length - 1; ++i)
				req.push((data.elements[i].value).trim());
			req = req.join(",");
			var xml = new XMLHttpRequest();
			xml.onload = function() {
				if (this.status == 200) {
					var res = this.responseText;
					//console.log(res);
					var lerr = document.querySelector(".popup-error2");
					var lsuc = document.querySelector(".popup-success2");
					if (res == 204) {
						lerr.style.display = "block";
						lsuc.style.display = "none";
						lerr.textContent = "Data gagal diperbarui ulangi!";
					} else if (res == 205) {
						lerr.style.display = "block";
						lsuc.style.display = "none";
						lerr.textContent = "Tidak ditemukan permbaruan.";
					} else {
						lerr.style.display = "none";
						lsuc.style.display = "block";
						lsuc.textContent = "Data berhasil diperbarui";
						processTable(res);
					}
				}
			}
			xml.open("POST", "edit.php", true);
			xml.send(req);
			return false;
		}


		function hapus(e) {
			if (confirm("Apakah Anda Yakin?") == true) {
				var xml = new XMLHttpRequest();
				xml.onload = function() {
					if (this.status == 200) {
						var res = this.responseText;
						if (res == 204) {
							window.alert("Gagal menghapus data, Ulangi!");
							return false;
						} else {
							processTable(res);
						}
					}
				}
				xml.open("POST", "remove.php", true);
				xml.send(e.getAttribute("data-id"));
			} else
				return false;
		}

		function edit(val) {
			document.querySelector(".popup-background2").classList.add("active");
			document.querySelector(".popup-error2").style.display = "none";
			document.querySelector(".popup-success2").style.display = "none";
			row_i = val.parentNode.parentNode.rowIndex;
			tb = document.querySelector("#a_list");
			fr = document.querySelector("#popup-form2");
			for (var i = 0; i < tb.rows[row_i].cells.length - 2; ++i) {
				fr.elements[i].value = tb.rows[row_i].cells[i].textContent.trim();
			}

		}
	</script>
</body>

</html>

<?php $db = null; ?>