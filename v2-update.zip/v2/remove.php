<?php

session_start();

$db = new PDO("mysql:host=127.0.0.1;dbname=smartparking", "smartparking", "sm4rtp4rk1ng991");
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_SESSION['loginsession'])) {
	$data = file_get_contents('php://input');
	$x = trim($data);
	$sql = "DELETE FROM pelanggan WHERE id = ?";
	$stmt = $db->prepare($sql);
	$stmt->bindValue(1, $x, PDO::PARAM_INT);
	$stmt->execute();

	if ($stmt->rowCount() > 0) {
		try {
			$sql = "SELECT * FROM pelanggan";
			$stmt = $db->query($sql);
			$ret = $stmt->fetchAll(PDO::FETCH_ASSOC);
			$trer = array("u" => strtoupper($_SESSION['loginsession']), "d" => $ret);
			echo json_encode($trer);
		} catch (Exception $e) {
			echo 204;
		}
	} else {
		echo 204;
	}
}

$db = null;
