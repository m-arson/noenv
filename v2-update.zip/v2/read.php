<?php

$db = new PDO("mysql:host=127.0.0.1;dbname=smartparking", "smartparking", "sm4rtp4rk1ng991");
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $data = $_POST['data'];
    $data = explode("//", $data);
    $id = $data[0];
    $pin = $data[1];
    $kurang = (int) $data[2];
    $sql = "SELECT sisa_saldo, pin FROM pelanggan WHERE id = ?";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(1, $id);
    if ($stmt->execute()) {
        if ($stmt->rowCount() > 0) {
            $res = $stmt->fetch(PDO::FETCH_ASSOC);
            $jatah = $res['sisa_saldo'] - $kurang;
            if ($jatah < 0) {
                echo "saldo_tidak_cukup";
            } else if ($res['pin'] != $pin) {
                echo "pin_salah";
            } else {
                $sql = "UPDATE pelanggan SET sisa_saldo = ? WHERE id = ?";
                $stmt = $db->prepare($sql);
                $stmt->bindParam(1, $jatah);
                $stmt->bindParam(2, $id);
                $stmt->execute();
                echo "berhasil";
            }
        } else {
            echo "id_tidak_ditemukan";
        }
    }
}
$db = null;
