<?php

session_start();

$db = new PDO("mysql:host=127.0.0.1;dbname=smartparking", "smartparking", "sm4rtp4rk1ng991");
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_SESSION['loginsession'])) {
	$data = file_get_contents('php://input');

	$data = explode(",", $data);

	$x = trim($data[0]);
	$y = trim($data[1]);
	$z = trim($data[2]);
	$a = trim($data[3]);
	$b = trim($data[4]);


	$sql = "SELECT * FROM pelanggan WHERE id = ?";
	$stmt = $db->prepare($sql);
	$stmt->bindValue(1, $x, PDO::PARAM_INT);
	$stmt->execute();

	if (count($stmt->fetch()) > 1) {
		echo 205;
	} else {
		try {
			$sql = "INSERT INTO pelanggan (id,nama,alamat,pin,sisa_saldo) VALUES(?,?,?,?,?)";
			$stmt = $db->prepare($sql);
			$stmt->bindValue(1, $x, PDO::PARAM_INT);
			$stmt->bindValue(2, $y, PDO::PARAM_STR);
			$stmt->bindValue(3, $z, PDO::PARAM_STR);
			$stmt->bindValue(4, $a, PDO::PARAM_STR);
			$stmt->bindValue(5, $b, PDO::PARAM_INT);
			$stmt->execute();

			if ($stmt->rowCount() > 0) {
				$sql = "SELECT * FROM pelanggan";
				$stmt = $db->query($sql);
				$ret = $stmt->fetchAll(PDO::FETCH_ASSOC);
				$trer = array("u" => strtoupper($_SESSION['loginsession']), "d" => $ret);
				echo json_encode($trer);
			} else {
				echo 204;
			}
		} catch (Exception $e) {
			echo 204;
		}
	}
}

$db = null;
