<?php

$db = new PDO("mysql:host=127.0.0.1;dbname=smartparking", "smartparking", "sm4rtp4rk1ng991");
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$sql = "SELECT nama,alamat,sisa_saldo,akses_terakhir FROM pelanggan";
$stmt = $db->query($sql);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

function order($a, $b)
{
    $by = $_GET['by'];
    $asc = $_GET['asc'];

    if ($a[$by] == $b[$by])
        return 0;
    if ($asc == 1)
        return ($a[$by] < $b[$by]) ? -1 : 1;
    else
        return ($a[$by] > $b[$by]) ? -1 : 1;
}

if ($_GET['by'] != "" && $_GET['asc'] != "")
    usort($data, "order");

echo json_encode($data);

$db = null;
