<?php

session_start();

$db = new PDO("mysql:host=127.0.0.1;dbname=smartparking", "smartparking", "sm4rtp4rk1ng991");
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


if ($_SERVER['REQUEST_METHOD'] == "POST") {
	try {
		$data = file_get_contents('php://input');
		$data = explode(",", $data);

		$u = trim($data[0]);
		$p = trim($data[1]);

		$sql = "SELECT * FROM admin WHERE username = ?";
		$stmt = $db->prepare($sql);
		$stmt->bindValue(1, $u);
		$stmt->execute();

		if ($stmt->rowCount() > 0) {
			$sdata = $stmt->fetch();
			if ($p == $sdata['password']) {
				$_SESSION['loginsession'] = $sdata['fullname'];
				$sql = "SELECT * FROM pelanggan";
				$stmt = $db->query($sql);
				$ret = $stmt->fetchAll(PDO::FETCH_ASSOC);
				$trer = array("u" => strtoupper($_SESSION['loginsession']), "d" => $ret);
				echo json_encode($trer);
			} else {
				echo 204;
			}
		} else {
			echo 204;
		}
	} catch (Exception $e) {
		echo $e->getMessage();
	}
}

$db = null;
